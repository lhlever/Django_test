from django.http import HttpResponse,JsonResponse
from django.shortcuts import render
from django.db import connection
import json
def insert(request):
    # print(request.GET.get("score"))
    # print("前台返回的值的类型为",type(request.GET.get("score")))
    # 删除前台的提交值的首末两个引号'
    x=request.GET.get("score").strip('\'')
    # print("转换后的类型为",type(json.loads(x)))
    # 把字符串类型的json转换成字典
    result=json.loads(x)
    # print(result['name'])
    #取出json中的name的值，并且在前后加上'
    str="\'"+result['name']+"\'"
    # print(str)
    #字典中去除name的记录
    result.pop('name')
    # print(request)
    #把成绩记录（字典类型）转换成字符串类型，并在前后加上'
    score="\'"+json.dumps(result)+"\'"
    # print(score)
    print("insert into t_score(name,score) values ("+str+","+score+")")
    cursor=connection.cursor()
    cursor.execute("insert into t_score(name,score) values ("+str+","+score+")")
    return JsonResponse({"result": 0, "msg": "执行成功"})

#建立一个url映射，转向admin.html
def admin(request):
    return render(request,'admin.html')

#用于查询成绩
def query(request):
    print("有人调用我这个接口了")
    cursor=connection.cursor()
    cursor.execute("select name,score from t_score")
    rows = cursor.fetchall()
    # print(type(rows))
    result=[]
    for row in rows:
        # print(type(row[0]))
        # print(str(row[0])+str(row[1])+"\n")
        item="{\"name\":\""+row[0]+"\",\"score\":"+json.dumps(row[1])+"}"
        # print(item)
        # print(type(json.loads(item)))
        result.append(json.loads(item))
    print("调用完成")
    return JsonResponse(result,safe=False)